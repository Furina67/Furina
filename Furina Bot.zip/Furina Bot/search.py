import discord
from discord.ext import commands
import aiohttp

API_KEY = "AIzaSyBtI-xfQrv0LhN-ut4MWIEcLA0RU45xo70"  # paste your full key
CSE_ID = "f10c2ca0fc50341ea"

class GoogleSearch(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="search")
    async def search(self, ctx, *, query: str):
        """Search Google using Custom Search API."""
        await ctx.trigger_typing()

        url = "https://customsearch.googleapis.com/customsearch/v1"

        params = {
            "key": API_KEY,
            "cx": CSE_ID,
            "q": query,
            "num": 3
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as response:
                    data = await response.json()

            if "items" not in data:
                return await ctx.reply("❌ No results found.")

            embed = discord.Embed(
                title=f"🔍 Google Search: {query}",
                color=0x00A2E8
            )

            for item in data["items"]:
                title = item.get("title", "No title")
                snippet = item.get("snippet", "No description")
                link = item.get("link", "")

                embed.add_field(
                    name=title,
                    value=f"{snippet}\n[Open Link]({link})",
                    inline=False
                )

            embed.set_footer(text="Powered by Google Custom Search API")

            await ctx.reply(embed=embed)

        except Exception as e:
            await ctx.reply(f"⚠️ Error: `{e}`")

async def setup(bot):
    await bot.add_cog(GoogleSearch(bot))